<nav id="sidebar" class="active" style="background-color: #022069;">
    <center><a href="home.php" class="logo"><img src="assets/images/ourlogo.png" alt=""></a>
    </center>
  <ul class="list-unstyled components mb-5">
    <li class="active">
      <a href="home.php"><span class="fab fa-delicious"></span>داشبۆرد</a>
    </li>
    <li>
      <a href="javascript:;" data-toggle="collapse" data-target="#books"><span class="fas fa-scroll"></span>فۆرم</a>
      <ul id="books" class="collapse">
        <li class="wrapper-color">
          <a href="NewForm.php">فۆرمەکا نووی</a>
        </li>
        <li class="wrapper-color">
          <a href="AllForm.php">هەمی فۆرم</a>
        </li>
      </ul>
    </li>
    <li>
      <a href="javascript:;" data-toggle="collapse" data-target="#accounts"><span class="far fa-money-bill-alt"></span>خەرجی</a>
      <ul id="accounts" class="collapse">
        <li class="wrapper-color">
          <a href="expense.php">خەرجیێن ئەڤرۆ</a>
        </li>
        <li class="wrapper-color">
          <a href="AllExpense.php">هەمی خەرجی</a>
        </li>
      </ul>
    </li>
    <li>
      <a href="debt.php"><span class="fas fa-hand-holding-usd"></span>قەرز</a>
    </li>
    <li>
      <a href="javascript:;" data-toggle="collapse" data-target="#koga"><span class="fas fa-warehouse"></span>کوگە</a>
      <ul id="koga" class="collapse">
        <li class="wrapper-color">
          <a href="koga.php">زێدەکرن بۆ کۆگەهێ</a>
        </li>
        <li class="wrapper-color">
          <a href="ShowKoga.php">بینینا کۆگەهێ</a>
        </li>
      </ul>
    </li>
    <li>
      <a href="OurData.php"><span class="fas fa-inbox"></span>فایدە</a>
    </li>
    <li>
      <a href="AllOurData.php"><span class="fas fa-inbox"></span> فایدە گشتی</a>
    </li>
  </ul>
  <div class="footer">
    <p>
      Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Developed By Dlbrin Azad  <i class="icon-heart" aria-hidden="true"></i>
    </p>
  </div>
</nav>