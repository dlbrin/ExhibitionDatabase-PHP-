<div class="nn">
<nav class="navbar dd navbar-expand-lg" style="background: #dde1e7; border-radius: 3px;
  box-shadow: -3px -3px 7px #ffffff73, 3px 3px 5px rgba(94, 104, 121, 0.288); ">
  <div class="container-fluid">
    <button type="button" id="sidebarCollapse" class="btn" style="background-color: #022069;">
      <i class="fas fa-bars" style="color: white;"></i>
    <span class="sr-only">Toggle Menu</span>
    </button>
    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <i class="fas fa-bars"></i>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="nav navbar-nav ml-auto">
        <li class="nav-item active">
          <div class="nav-item-admin">
            <img src="assets/images/RastiLogo.jpg" alt="">
            <h4>پێشانگەها راستی</h4>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="?logout"><img src="assets/images/logout.svg" alt=""></a>
        </li>
      </ul>
    </div>
  </div>
</nav>
</div>